<?php

namespace App;

class Seller extends User
{
    //
}
