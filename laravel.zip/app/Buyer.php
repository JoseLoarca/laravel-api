<?php

namespace App;

class Buyer extends User
{
    //
}
